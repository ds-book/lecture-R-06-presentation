#### Подготовка данных ####

source("_prepare.R")

#### Excel ####

library(openxlsx)

##### Простое сохранение #####

write.xlsx(data, "data/myworkbook.xlsx")

# Сохранение каждой таблицы на отдельном листе
write.xlsx(list("Количество" = data, "Возраст" = data_age), 
           file = "data/myworkbook.xlsx",
           asTable = TRUE)

# Дополним недостающие данные
data_excel <- data %>% 
  mutate(diagnosis = ifelse(is.na(diagnosis), "Неуточненный", diagnosis),
         percent_diag = round(ifelse(is.na(percent_diag), 0, percent_diag), 2),
         percent_overall = round(percent_overall, 2)
         )

##### Оформление таблицы #####

# Создаем книгу
wb <- createWorkbook()

# Добавляем лист
sheet = "Данные"
addWorksheet(wb, sheetName = sheet, gridLines = TRUE)

##### Заголовок для таблицы #####

# Пишем заголовок
writeData(wb, sheet, "Заголовок для таблицы", startCol = 1, startRow = 1)
# Объединяем первые три ячейки, чтобы записать заголовок
mergeCells(wb, sheet, cols = 1:ncol(data_excel), rows = 1)
# saveWorkbook(wb, "data/openxlsx_report.xlsx", overwrite = TRUE)

# Пишем на новый лист таблицу со второй строки
writeData(wb, sheet, data_excel, colNames = TRUE, rowNames = FALSE, startCol = 1, startRow = 2)
# saveWorkbook(wb, "data/openxlsx_report.xlsx", overwrite = TRUE)

# Устанавливаем автоматическую ширину столбцов
setColWidths(wb, sheet, cols = 1:ncol(data_excel), widths = "auto")
# saveWorkbook(wb, "data/openxlsx_report.xlsx", overwrite = TRUE)

# Создадим стиль для заголовка
headerStyle <- createStyle(fontSize = 12, fontColour = "black",
                           halign = "center", valign = "center", fgFill = "mistyrose",
                           border = "TopBottomLeftRight", borderColour = "black",
                           textDecoration = "bold", wrapText = TRUE)
# Применим стиль для текста заголовка таблицы
addStyle(wb, sheet, headerStyle, rows = 1, cols = 1, gridExpand = TRUE)
# saveWorkbook(wb, "data/openxlsx_report.xlsx", overwrite = TRUE)

##### Заголовок для столбцов #####

# Создадим стиль для заголовков столбцов таблицы
tableHeaderStyle <- createStyle(fontSize = 12, fontColour = "black",
                                halign = "center", valign = "center", fgFill = "lightcyan2",
                                border = "TopBottomLeftRight", borderColour = "black",
                                textDecoration = "bold", wrapText = TRUE)
# Применим стиль для заголовков столбцов таблицы
addStyle(wb, sheet, tableHeaderStyle, rows = 2, cols = 1:ncol(data_excel), gridExpand = TRUE)

# Сохранение файла
saveWorkbook(wb, "data/openxlsx_report.xlsx", overwrite = TRUE)

##### Окрашивание ячеек #####

# Создаем книгу
wb <- createWorkbook()

# Добавляем лист
sheet2 = "cytomegalovirus"
d <- cytomegalovirus
d[is.na(d)] <- 0

addWorksheet(wb, sheet2, gridLines = TRUE)
writeData(wb, sheet2, d, colNames = TRUE, rowNames = FALSE, na.string = "")
saveWorkbook(wb, "data/openxlsx_report2.xlsx", overwrite = TRUE)

# Почитаем строки 
n <- nrow(cytomegalovirus)
first_data_row <- 2
last_data_row  <- 1 + n   # = 2 + n - 1
all_rows       <- 1:(1 + n)
data_rows      <- 2:(1 + n)

# Условное форматирование на равенство/неравенство
conditionalFormatting(wb, sheet2,
                      style = createStyle(bgFill = "salmon"),
                      cols = 3, 
                      rows = 2:(1 + n), 
                      type = "expression",
                      rule = "==1")
saveWorkbook(wb, "data/openxlsx_report2.xlsx", overwrite = TRUE)

# Градиентное окрашивание
conditionalFormatting(wb, sheet2,
                      style = c("white", "red"),
                      cols = 2,
                      rows = 2:(1 + n), 
                      type = "colourScale",
                      rule = c(29, 70))
saveWorkbook(wb, "data/openxlsx_report2.xlsx", overwrite = TRUE)

# Подсветка одинаковых значений
conditionalFormatting(wb, sheet2,
                      style = createStyle(bgFill = "gold"),
                      cols = 7,
                      rows = 2:(1 + n), 
                      type = "duplicates")
saveWorkbook(wb, "data/openxlsx_report2.xlsx", overwrite = TRUE)

# Топ значений
conditionalFormatting(wb, sheet2,
                      style = createStyle(bgFill = "cyan"),
                      cols = 7,
                      rows = 2:(1 + n),
                      type = "topN",
                      rank = 10, percent = TRUE)

saveWorkbook(wb, "data/openxlsx_report2.xlsx", overwrite = TRUE)

# Значения которые начинаются
conditionalFormatting(wb, sheet2,
                      style = createStyle(bgFill = "green"),
                      cols = 5,
                      rows = 2:(1 + n),  
                      type = "beginsWith",
                      rule = "Hodgkin")
saveWorkbook(wb, "data/openxlsx_report2.xlsx", overwrite = TRUE)

# Сохраним документ
saveWorkbook(wb, "data/openxlsx_report2.xlsx", overwrite = TRUE)


#### Рекомендации по оформлению таблиц ####

library(gt)
library(gtExtras)

# Подготовим таблицу, с которой будем работать
dt <- cytomegalovirus %>% mutate(
  sex = ifelse(sex == 1, "мужской", "женский"),
  sex_eng = ifelse(sex == "мужской", "Male", "Female"),
  race = ifelse(race == 1, "White", "African American"),
  diagnosis.type = ifelse(diagnosis.type == 1, "lymphoid", "myeloid")
) %>% 
  mutate(sex_race = paste(sex_eng, race, sep = " " ))
dt

##### 1 Отделяйте заголовки от тела таблицы #####

dt %>%  select(ID, age, sex, diagnosis.type, TNC.dose, CD34.dose, CD3.dose) %>% head() %>% 
  gt() %>% 
  tab_style(
    style = list(
      cell_text(weight = "bold")
    ),
    locations = cells_column_labels(everything())
  ) %>% 
  opt_table_lines(extent = "default") %>%
  tab_options(
    column_labels.border.top.color = "white",
    column_labels.border.top.width = px(3),
    column_labels.border.bottom.color = "black",
    table_body.hlines.color = "white",
    table.border.bottom.color = "white",
    table.border.bottom.width = px(3)
  )


##### 2 Используйте ненавязчивые разделители вместо сетки ##### 

dt1 <- dt %>%  select(diagnosis, time.to.cmv, time.to.agvhd, time.to.cgvhd, TNC.dose, CD34.dose, CD3.dose) %>% 
  group_by(diagnosis) %>%
  summarise(
    time.to.cmv = mean(time.to.cmv, na.rm = TRUE), 
    time.to.agvhd = mean(time.to.agvhd, na.rm = TRUE), 
    time.to.cgvhd = mean(time.to.cgvhd, na.rm = TRUE), 
    TNC.dose = mean(TNC.dose, na.rm = TRUE), 
    CD34.dose = mean(CD34.dose, na.rm = TRUE), 
    CD3.dose = mean(CD3.dose, na.rm = TRUE)
  ) %>% ungroup() %>% head() 

dt1 <- dt1 %>% 
  add_row(
    dt1 %>% 
      summarize(
        across(where(is.double), 
               list(Average = mean),
               .names = "{col}")
      ) %>% 
      mutate(diagnosis = "Average")
  )

dt1 %>% 
  gt() %>% 
  tab_spanner(label = "time to", columns = starts_with("time.")) %>% 
  tab_spanner(label = "dose", columns = ends_with(".dose")) %>% 
  cols_label(
    time.to.cmv = "cmv", time.to.agvhd = "agvhd", time.to.cgvhd = "cgvhd",
    TNC.dose = "TNC", CD34.dose = "CD34", CD3.dose = "CD3"
  ) %>% 
  fmt_number(columns = where(is.double) ) %>% 
  tab_options(
    column_labels.border.top.width = px(0),
    column_labels.border.bottom.color = "grey20",
    column_labels.border.bottom.width= px(2),
    column_labels.font.weight = "bold",
    table.border.top.style = "none"
  ) %>% 
  tab_style(
    style = list(
      cell_text(style = "italic", weight = "bold"),
      cell_borders(
        sides = c("top"),
        color = "grey20",
        weight = px(5),
        style = "double"
      )
    ),
    locations = cells_body(
      rows = diagnosis == "Average"
    )
  ) %>% 
  tab_style(
    style = list(
      cell_borders(
        sides = "right",
        color = "grey20",
        weight = px(1),
        style = "solid"
      )
    ),
    locations = cells_body(columns  = c(1,4))
  )



##### 3 Выравнивайте числа по правому краю #####

dt1 %>%  select(diagnosis, time.to.cmv, time.to.agvhd, time.to.cgvhd) %>% head() %>% 
  gt() %>% 
  tab_style(
    style = list(
      cell_text(weight = "bold")
    ),
    locations = cells_column_labels(everything())
  ) %>% 
  cols_label(
    time.to.cmv = "левый", time.to.agvhd = "центр", time.to.cgvhd = "правый"
  ) %>% 
  fmt_number(columns = where(is.double) ) %>% 
  cols_align(align = "left",
             columns = 2) %>% 
  cols_align(align = "center",
             columns = 3) %>% 
  cols_align(align = "right",
             columns = 4)


##### 4 Выравнивайте текст по левому краю #####

dt1 %>%  select(diagnosis) %>% head() %>% 
  mutate(
    left   = diagnosis,
    center = diagnosis,
    right  = diagnosis
  ) %>% 
  select(-diagnosis) %>% 
  gt() %>% 
  tab_style(
    style = list(
      cell_text(weight = "bold")
    ),
    locations = cells_column_labels(everything())
  ) %>% 
  cols_label(left = "левый", center = "центр", right = "правый") %>% 
  cols_align(align = "left",
             columns = 1) %>% 
  cols_align(align = "center",
             columns = 2) %>% 
  cols_align(align = "right",
             columns = 3)

dt %>% mutate(cmv = ifelse(cmv == 1, "да", "нет")) %>% 
  select(diagnosis, cmv, age) %>% head() %>% 
  gt() %>% 
  cols_label(diagnosis = "левый", cmv = "центр", age = "правый") %>% 
  tab_style(
    style = list(
      cell_text(weight = "bold")
    ),
    locations = cells_column_labels(everything())
  ) %>% 
  cols_align(align = "center", columns = 2)

##### 5 Адекватный уровень точности #####

dt1 %>% head() %>% select(diagnosis, TNC.dose) %>% 
  mutate(few = TNC.dose, right = TNC.dose) %>% 
  gt() %>% 
  tab_style(
    style = list(
      cell_text(weight = "bold")
    ),
    locations = cells_column_labels(everything())
  ) %>% 
  fmt_number(
    columns = c(few),
    decimals = 0
  ) %>% 
  fmt_number(
    columns = c(right),
    decimals = 2
  ) %>% 
  cols_label(
    TNC.dose = md("Много"),
    few = md("Мало"),
    right = md("В самый раз")
  )

##### 6 Направление читателя с помощью отступов #####

# Вертикаль
dt1 %>% 
  gt() %>% 
  tab_options(
    data_row.padding = px(1),
    table_body.hlines.color = "lightgrey") %>% 
  fmt_number(columns = where(is.double)) %>% 
  tab_spanner(label = "time to", columns = starts_with("time.")) %>% 
  tab_spanner(label = "dose", columns = ends_with(".dose")) %>% 
  cols_label(
    time.to.cmv = "cmv", time.to.agvhd = "agvhd", time.to.cgvhd = "cgvhd",
    TNC.dose = "TNC", CD34.dose = "CD34", CD3.dose = "CD3"
  ) %>% 
  tab_style(
    style = list(
      cell_text(weight = "bold")
    ),
    locations = cells_column_labels(everything())
  ) %>% 
  tab_style(
    style = list(
      cell_text(weight = "bold")
    ),
    locations = cells_column_spanners(everything())
  ) %>% 
  tab_style(
    style = list(
      cell_borders(
        sides = c("bottom"),
        weight = px(1),
        style = "hidden"
      )
    ),
    locations = cells_body(
      rows = !diagnosis %in% c("Average" ,"chronic myeloid leukemia")
    )
  ) %>% 
  tab_style(
    style = list(
      cell_borders(
        sides = c("top"),
        color = "grey20",
        weight = px(1),
        style = "solid"
      )
    ),
    locations = cells_body(
      rows = diagnosis == "Average"
    )
  ) %>% 
  cols_width(c(diagnosis) ~ px(225),
             2 ~ px(85), 3:4 ~px(70),
             5 ~ px(85), 6:7 ~px(70)) 


# Горизонталь
dt1 %>% 
  gt() %>% 
  tab_options(data_row.padding = px(2),
              table_body.hlines.color = "lightgrey") %>% 
  fmt_number(columns = where(is.double)) %>% 
  tab_spanner(label = "time to", columns = starts_with("time.")) %>% 
  tab_spanner(label = "dose", columns = ends_with(".dose")) %>% 
  cols_label(
    time.to.cmv = "cmv", time.to.agvhd = "agvhd", time.to.cgvhd = "cgvhd",
    TNC.dose = "TNC", CD34.dose = "CD34", CD3.dose = "CD3"
  ) %>% 
  tab_style(
    style = list(
      cell_text(weight = "bold")
    ),
    locations = cells_column_labels(everything())
  ) %>% 
  tab_style(
    style = list(
      cell_text(weight = "bold")
    ),
    locations = cells_column_spanners(everything())
  ) %>% 
  tab_style(
    style = list(
      cell_borders(
        sides = c("top"),
        color = "grey20",
        weight = px(1),
        style = "solid"
      )
    ),
    locations = cells_body(
      rows = diagnosis == "Average"
    )
  ) %>% 
  cols_width(2 ~ px(65), 3:4 ~px(45),
             5 ~ px(65), 6:7 ~px(45)) %>% 
  tab_style(style = cell_fill(color = "grey97"),
            locations = cells_body(rows = seq(1, 7, 2)))

##### 7 Единицы измерения #####

# Вариант 1
dt1 %>% select(diagnosis, TNC.dose, CD34.dose, CD3.dose) %>% 
  gt() %>% 
  # tab_options(data_row.padding = px(10),
  #             table_body.hlines.color = "white") %>% 
  fmt_number(columns = where(is.double)) %>%  
  cols_label(TNC.dose = "TNC, x10<sup>8</sup>/kg", 
             CD34.dose = "CD34, x10<sup>6</sup>/kg", 
             CD3.dose = "CD3, x10<sup>8</sup>/kg", 
             .fn = md) %>% 
  cols_width(c(diagnosis) ~ px(256)) %>% 
  tab_style(
    style = list( 
      cell_text(weight = "bold"),
      cell_borders(sides = c("bottom"), color = "black", weight = px(2), style = "solid"),
      cell_borders(sides = c("top"),  style = "hidden")),
    locations = cells_column_labels(everything())
  ) %>% 
  tab_style(
    style = list( 
      cell_text(weight = "bold"),
      cell_borders(sides = c("top"), color = "black", weight = px(2), style = "solid"),
      cell_borders(sides = c("bottom"),  style = "hidden")
    ),
    locations = cells_body(rows = diagnosis == "Average")
  ) 

# Вариант 2
dt1 %>% select(diagnosis, TNC.dose, CD34.dose, CD3.dose) %>% 
  gt() %>% 
  # tab_options(data_row.padding = px(10),
  #             table_body.hlines.color = "white") %>% 
  fmt_number(columns = where(is.double)) %>%  
  cols_label(TNC.dose = "TNC", CD34.dose = "CD34", CD3.dose = "CD3") %>% 
  cols_width(c(diagnosis) ~ px(256)) %>% 
  tab_style(
    style = list( 
      cell_text(weight = "bold"),
      cell_borders(sides = c("bottom"), color = "black", weight = px(2), style = "solid"),
      cell_borders(sides = c("top"),  style = "hidden")),
    locations = cells_column_labels(everything())
  ) %>% 
  tab_style(
    style = list( 
      cell_text(weight = "bold"),
      cell_borders(sides = c("top"), color = "black", weight = px(2), style = "solid")
    ),
    locations = cells_body(rows = diagnosis == "Average")
  ) %>% 
  tab_footnote(
    footnote = md("Total nucleated cell dose, x10<sup>8</sup>/kg"),
    locations = cells_column_labels(c(2))
  ) %>% 
  tab_footnote(
    footnote = md("CD34+ cell dose, x10<sup>6</sup>/kg"),
    locations = cells_column_labels(3)
  ) %>% 
  tab_footnote(
    footnote = md("CD3+ cell dose, x10<sup>8</sup>/kg"),
    locations = cells_column_labels(4)
  )

##### 8 Выделение выбросов #####

# Подготовим таблицу для отображения
dt2 <- dt %>%  select(sex_race, diagnosis, age) %>% 
  group_by(sex_race, diagnosis) %>% 
  summarize(avg.age = mean(age, na.rm = TRUE),
            n = n()) %>% 
  ungroup() %>% 
  arrange(-n)
dt2

dt2pivot <- dt2 %>% 
  select(sex_race, diagnosis, avg.age) %>% 
  pivot_wider(names_from = sex_race, values_from = avg.age)
dt2pivot

# Обычная таблица
dt2pivot %>% 
  gt() %>% 
  fmt_number(decimals = 0) %>% 
  tab_spanner(label = "White", columns = ends_with("White")) %>% 
  tab_spanner(label = "African American", columns = ends_with("African American")) %>% 
  cols_label(`Male White` = "Male", `Female White` = "Female", 
             `Male African American` = "Male", `Female African American` = "Female") %>% 
  tab_style(
    style = list( 
      cell_text(weight = "bold"),
      cell_borders(sides = c("bottom"), color = "black", weight = px(2), style = "solid"),
      cell_borders(sides = c("top"),  style = "hidden")),
    locations = cells_column_labels(everything())
  ) %>% 
  tab_style(
    style = list(
      cell_text(weight = "bold")
    ),
    locations = cells_column_spanners(everything())
  ) %>% 
  sub_missing(missing_text = "-")


# Выделение цветом
dt2pivot %>% 
  gt() %>% 
  fmt_number(decimals = 0) %>% 
  tab_spanner(label = "White", columns = ends_with("White")) %>% 
  tab_spanner(label = "African American", columns = ends_with("African American")) %>% 
  cols_label(`Male White` = "Male", `Female White` = "Female", 
             `Male African American` = "Male", `Female African American` = "Female") %>% 
  tab_style(
    style = list( 
      cell_text(weight = "bold"),
      cell_borders(sides = c("bottom"), color = "black", weight = px(2), style = "solid"),
      cell_borders(sides = c("top"),  style = "hidden")),
    locations = cells_column_labels(everything())
  ) %>% 
  tab_style(
    style = list(
      cell_text(weight = "bold")
    ),
    locations = cells_column_spanners(everything())
  ) %>% 
  tab_style(
    style = cell_text(color = "green4", weight = "bold"),
    locations = list(cells_body(columns = `Male White`,rows = `Male White` > 60))
  ) %>% 
  tab_style(
    style = cell_text(color = "green4", weight = "bold"),
    locations = list(cells_body(columns = `Female White`,rows = `Female White` > 60))
  ) %>% 
  tab_style(
    style = cell_text(color = "green4", weight = "bold"),
    locations = list(cells_body(columns = `Male African American`,rows = `Male African American` > 60))
  ) %>% 
  tab_style(
    style = cell_text(color = "green4", weight = "bold"),
    locations = list(cells_body(columns = `Female African American`,rows = `Female African American` > 60))
  ) %>% 
  tab_style(
    style = cell_text(color = "red3", weight = "bold"),
    locations = list(cells_body(columns = `Male White`,rows = `Male White` < 40))
  ) %>% 
  tab_style(
    style = cell_text(color = "red3", weight = "bold"),
    locations = list(cells_body(columns = `Female White`,rows = `Female White` < 40))
  ) %>% 
  tab_style(
    style = cell_text(color = "red3", weight = "bold"),
    locations = list(cells_body(columns = `Male African American`,rows = `Male African American` < 40))
  ) %>% 
  tab_style(
    style = cell_text(color = "red3", weight = "bold"),
    locations = list(cells_body(columns = `Female African American`,rows = `Female African American` < 40))
  ) %>% 
  sub_missing(missing_text = "-")

# Выделение заливкой
dt2pivot %>% 
  gt() %>% 
  fmt_number(decimals = 0) %>% 
  tab_spanner(label = "White", columns = ends_with("White")) %>% 
  tab_spanner(label = "African American", columns = ends_with("African American")) %>% 
  cols_label(`Male White` = "Male", `Female White` = "Female", 
             `Male African American` = "Male", `Female African American` = "Female") %>% 
  tab_style(
    style = list( 
      cell_text(weight = "bold"),
      cell_borders(sides = c("bottom"), color = "black", weight = px(2), style = "solid"),
      cell_borders(sides = c("top"),  style = "hidden")),
    locations = cells_column_labels(everything())
  ) %>% 
  tab_style(
    style = list(
      cell_text(weight = "bold")
    ),
    locations = cells_column_spanners(everything())
  ) %>% 
  tab_style(
    style = list(
      cell_fill(color = scales::alpha("#2E8B57", 0.7)),
      cell_text(color = "white", weight = "bold")
    ),
    locations = list(
      cells_body(columns = `Male White`,rows = `Male White` > 60),
      cells_body(columns = `Female White`,rows = `Female White` > 60),
      cells_body(columns = `Male African American`,rows = `Male African American` > 60),
      cells_body(columns = `Female African American`,rows = `Female African American` > 60)
    )
  ) %>% 
  tab_style(
    style = list(
      cell_fill(color = scales::alpha("red", 0.7)),
      cell_text(color = "white", weight = "bold")
    ),
    locations = list(
      cells_body(columns = `Male White`,rows = `Male White` < 40),
      cells_body(columns = `Female White`,rows = `Female White` < 40),
      cells_body(columns = `Male African American`,rows = `Male African American` < 40),
      cells_body(columns = `Female African American`,rows = `Female African American` < 40)
    )
  ) %>% 
  sub_missing(missing_text = "-")


##### 9 Группировка данных #####

# Подготовка таблицы
dt3 <- dt %>% select(diagnosis.type, diagnosis, time.to.transplant ) %>% 
  filter(!is.na(diagnosis.type)) %>% 
  group_by(diagnosis.type, diagnosis) %>% 
  summarise(n = n(), 
            time.to.transplant = mean(time.to.transplant, na.rm = TRUE),
            .groups = "drop") %>% 
  group_by(diagnosis.type) %>% 
  mutate(numbering = row_number()) %>% 
  ungroup() %>% 
  mutate(row_idx = row_number())

# Группировка
dt3 %>% gt(groupname_col = "diagnosis.type") %>% 
  # opt_table_lines(extent = "none") %>%
  fmt_number(columns = 3, decimals = 0) %>% 
  fmt_number(columns = 4, decimals = 2) %>% 
  cols_label(time.to.transplant = "time") %>% 
  cols_hide(c(numbering, row_idx)) %>% 
  tab_style(
    style = cell_text(color = "black", weight = "bold"),
    locations = list(
      cells_row_groups(),
      cells_column_labels(everything())
    )
  ) %>% 
  tab_style(
    style = list( 
      cell_text(weight = "bold"),
      cell_borders(sides = c("bottom"), color = "black", weight = px(2), style = "solid"),
      cell_borders(sides = c("top"),  style = "hidden")),
    locations = cells_column_labels(everything())
  ) %>% 
  tab_style(
    style = cell_text(color = "black", weight = "bold"),
    locations = list(
      cells_row_groups(),
      cells_column_labels(everything())
    )
  )


# Объединение
dt3 %>% gt() %>% 
  opt_table_lines(extent = "none") %>%
  cols_hide(c(numbering, row_idx)) %>% 
  fmt_number(columns = 3, decimals = 0) %>% 
  fmt_number(columns = 4, decimals = 2) %>% 
  cols_label(time.to.transplant = "time") %>% 
  tab_style(
    style = list( 
      cell_text(weight = "bold"),
      cell_borders(sides = c("bottom"), color = "black", weight = px(2), style = "solid"),
      cell_borders(sides = c("top"),  style = "hidden")),
    locations = cells_column_labels(everything())
  ) %>% 
  tab_style(
    style = list( 
      cell_text(weight = "bold"),
      cell_borders(sides = c("bottom"), color = "black", weight = px(2), style = "solid"),
      cell_borders(sides = c("top"),  style = "hidden")),
    locations = cells_column_labels(everything())
  ) %>% 
  tab_style(
    style = cell_borders(sides = "top", color = "#ffffff", weight = px(16)),
    locations = cells_body(
      columns = everything(),
      rows = numbering == 1 & row_idx != 1
    )
  ) %>% 
  text_transform(
    locations = cells_body(
      columns = c(diagnosis.type),
      rows = numbering != 1
    ),
    fn = function(x){
      paste0("")
    }
  ) 

##### 10 Визуализация данных #####

library(svglite)

# barplot
dt4 <- dt %>% 
  group_by(diagnosis) %>% 
  summarise(
    n = n() ,
    min = min(age, na.rm = TRUE),
    avg = mean(age, na.rm = TRUE),
    max = max(age, na.rm = TRUE),
    boxplot = list(age)) %>% 
  ungroup() %>% 
  arrange(-n) %>% head()

dt4 %>% 
  gt() %>% 
  gt_plt_dist( 
    boxplot,
    type = "boxplot"
  ) %>% 
  fmt_number(decimals = 0) %>% 
  tab_style(
    style = list( 
      cell_text(weight = "bold"),
      cell_borders(sides = c("bottom"), color = "black", weight = px(2), style = "solid"),
      cell_borders(sides = c("top"),  style = "hidden")),
    locations = cells_column_labels(everything())
  )

# heatmap 
dt5 <- dt %>% 
  group_by(diagnosis) %>% 
  summarise(n = n() ,
            trnsp = mean(time.to.transplant, na.rm = TRUE),
            cmv = mean(time.to.cmv, na.rm = TRUE),
            agvhd = mean(time.to.agvhd, na.rm = TRUE),
            cgvhd = mean(time.to.cgvhd, na.rm = TRUE)) %>% 
  ungroup() %>%   arrange(-n) %>% head()

dt5 %>% replace(is.na(.), 0) %>% 
  gt() %>% 
  fmt_number() %>% 
  cols_hide(n) %>%
  data_color(
    columns = 3:6, 
    colors = scales::col_numeric(
      palette = paletteer::paletteer_d(
        palette = "ggsci::blue_material"
      ) %>% as.character(),
      domain = NULL
    )
  ) %>% 
  data_color(
    columns = 3, 
    colors = scales::col_numeric(
      palette = paletteer::paletteer_d(
        palette = "ggsci::blue_material"
      ) %>% as.character(),
      domain = NULL
    )
  ) %>% 
  tab_style(
    style = cell_text(color = "black", weight = "bold"),
    locations = list(
      cells_column_spanners(everything()),
      cells_column_labels(everything())
    )
  ) 
