# Описательная статистика для числовых данных
calcNumericStat <- function(name, x, y = 2, na.omit = TRUE) {
  require(data.table)
  if (na.omit)
    x <- x[!is.na(x)]
  N <- length(x)
  AVG <- round((mean(x)), y)
  SD <- round((sd(x)), y)
  AVGSD <- paste0(AVG, (paste0(" \u00B1 ", SD)))
  Me <- round((median(x)), y)
  Q1 <- round((quantile(x, c(0.25))), y)
  Q3 <- round((quantile(x, c(0.75))), y)
  MeQ1Q3 <- paste0(Me, paste0(" ", "(", Q1, "; ", Q3, ")"))
  Min <- round((min(x)), y)
  Max <- round((max(x)), y)
  return(
    data.table(
      "Показатель" = name,
      N = N,
      "AVGSD" = AVGSD,
      "MeQ1Q3" = MeQ1Q3 ,
      Min = Min,
      Max = Max
    )
  )
}

# Описательная статистика категориальных данных
calcGroup <- function(data, group = c("Group")){
  require(data.table)
  require(binom)
  data <- as.data.table(data)
  colname <- c(group)
  names(data) <- c(colname)
  data <- data[is.na(get(colname[1])), c(colname[1]) := "Нет данных"]
  data<-data[, .(n = .N), by= c(colname)][,`:=`(Total=sum(n))][,c("%","low","up") := round((binom.confint(n,Total,methods = "wilson", conf.level=0.95)[,c(4:6)])*100,2)]
  data <- data[,`:=`(`95% CI`= paste0(low,"-",up))][,c("low","up") := NULL]
  colname <- names(data)
  data <- data[order(-get(colname[4]))]
  data <- as.data.frame(data)
  
  return(data)
}

# Описательная статистика категориальных данных в подгруппе
calcSubGroup <- function(data, group = c("Group"), sub_name = c("Subgroup")){
  require(data.table)
  require(binom)
  data <- as.data.table(data)
  colname <- c(group,sub_name)
  names(data) <- c(colname)
  data <- data[is.na(get(colname[1])), c(colname[1]) := "Нет данных"]
  data <- data[is.na(get(colname[2])), c(colname[2]) := "Нет данных"]
  data<-data[, .(n = .N), by= c(colname)][,`:=`(Total=sum(n)), by = c(colname[1])][,c("%","low","up") := round((binom.confint(n,Total,methods = "wilson", conf.level=0.95)[,c(4:6)])*100,2)]
  data <- data[order(get(colname[1]),-get(colname[2]))]
  data <- data[,`:=`(`95% CI`= paste0(low,"-",up))][,c("low","up") := NULL]
  colname <- names(data)
  data <- data[order(get(colname[1]),-get(colname[5]))]
  data <- as.data.frame(data)
  
  return(data)
}