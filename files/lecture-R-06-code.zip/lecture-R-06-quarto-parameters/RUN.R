library(here)
library(dplyr)

center_numbers <- c(32, 292, 290, 38, 18, 219, 177, 78, 512)

#### Одиночный отчет  ####
center_number <- 32
quarto::quarto_render(
  input = here("ReportTemplate.qmd"),
  output_file = paste0("report_", center_number, ".html"),
  output_format = format,
  execute_params = list(
    center = center_number,
    author = "Петров П.П."
  )
)


#### Рендер отчетов в цикле  #### 

# Функция для рендеринга отчета в цикле
render_center_report <- function(center_number, format) {
  ext <- switch(format,
                html = "html",
                docx = "docx",
                pdf  = "pdf"
  )
  
  quarto::quarto_render(
    input = here("ReportTemplate.qmd"),
    output_file = paste0("report_", center_number, ".", ext),
    output_format = format,
    execute_params = list(
      center = center_number,
      author = "Петров П.П."
    )
  )
}

# Использование функции для рендера одиночного отчета
center <- 32
render_center_report(center, "html")

# Использование функции в цикле
for (center in center_numbers) {
  print(paste0("Начало: ", center))
  render_center_report(center, "html")
  render_center_report(center, "docx")
  print(paste0("Конец: ", center))
}

#### Пакетный рендер отчетов ####

# Создаём базовый data.frame
reports <- data.frame(
  output_file = paste0("report_", sprintf("%03d", center_numbers), ".html"))
                      
# Добавляем столбец с параметрами как список
reports$execute_params <- mapply(
  function(center, author) {
    list(center = center, author = author)
  },
  center = center_numbers,
  author = "Иванов И.И.",  # или вектор авторов, если они разные
  SIMPLIFY = FALSE
)


# Теперь запускаем пакетный рендер отчетов
reports %>% 
  purrr::pwalk(
    quarto::quarto_render,
    input =  here("ReportTemplate.qmd"),
    output_format = "html"  
  )

# Повторим то же самое для docx
reports$output_file <- paste0("report_", sprintf("%03d", center_numbers), ".docx")
reports %>% 
  purrr::pwalk(
    quarto::quarto_render,
    input =  here("ReportTemplate.qmd"),
    output_format = "docx"  
  )
